import { useEffect, useMemo, useState } from 'react'
import type { TelemetryEvent } from './api'
import { Chart } from './Chart'

const traderActions = ['Value', 'Trend', 'Contrarian', 'Reduce']
const companyActions = ['Real investment', 'Disclosure', 'Maintain']
const palette = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4']
interface Delivery {
  source_id: string; target_id: string; event_time: string; available_at: string
  credibility: number; path: string[]; message_id: string
}
interface Frame {
  day: number; nodes: string[]; edges: { source_id: string; target_id: string; weight: number; trust: number; delay_days: number }[]
  trader_ids: string[]; company_ids: string[]; trader_actions: number[]; trader_types: number[]
  trader_states: number[]; trader_features: number[][]; factor_preferences: number[]; risk_aversion: number[]
  trader_probabilities: number[][]; bandit_values: number[][][]; q_values: number[][][]
  wealth: number[]; positions: number[]; submitted_orders: number[]; executed_orders: number[]
  visible_news: number[]; subjective_values: number[]; company_groups: number[]; company_states: number[]
  company_actions: number[]; company_features: number[][]; company_cash: number[]; arrivals: Delivery[]
  trader_rewards: { reward: number[]; gross_return: number[]; transaction_cost: number[]; volatility_penalty: number[]; drawdown_penalty: number[]; start_day: number; end_day: number } | null
  company_rewards: { names: string[]; components: number[][]; reward: number[]; start_day: number; end_day: number } | null
}

function Network({ frame, agent, company, source }: { frame: Frame; agent: string; company: string; source: string }) {
  const neighbors = new Set([agent, company])
  frame.edges.forEach((e) => { if (e.source_id === agent) neighbors.add(e.target_id); if (e.target_id === agent) neighbors.add(e.source_id) })
  const nodes = frame.nodes.length <= 60 ? frame.nodes : frame.nodes.filter((n) => neighbors.has(n))
  const points = new Map(nodes.map((n, i) => [n, [300 + 205 * Math.cos(i * Math.PI * 2 / nodes.length), 210 + 155 * Math.sin(i * Math.PI * 2 / nodes.length)]]))
  const paths = new Set<string>()
  frame.arrivals.filter((d) => source === 'all' || d.source_id === source).forEach((d) => d.path.slice(1).forEach((n, i) => paths.add(`${d.path[i]}|${n}`)))
  return <section className="chart-card"><header><div><h3>Information network</h3><p>{nodes.length} / {frame.nodes.length} nodes · orange paths arrived today</p></div></header>
    {nodes.length ? <svg viewBox="0 0 600 420" role="img" aria-label="Directed information graph"><defs><marker id="arrow" viewBox="0 0 10 10" refX="18" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke" /></marker></defs>
      {frame.edges.filter((e) => points.has(e.source_id) && points.has(e.target_id)).map((e) => <line key={`${e.source_id}|${e.target_id}`} x1={points.get(e.source_id)![0]} y1={points.get(e.source_id)![1]} x2={points.get(e.target_id)![0]} y2={points.get(e.target_id)![1]} stroke={paths.has(`${e.source_id}|${e.target_id}`) ? '#eb6834' : '#99a4af'} strokeWidth={paths.has(`${e.source_id}|${e.target_id}`) ? 3 : 1.5} markerEnd="url(#arrow)"><title>{`${e.source_id} → ${e.target_id}; delay ${e.delay_days}d; trust ${e.trust.toFixed(3)}; weight ${e.weight.toFixed(3)}`}</title></line>)}
      {nodes.map((n) => <g key={n}><circle cx={points.get(n)![0]} cy={points.get(n)![1]} r={n === agent || n === company ? 10 : 7} fill={n.startsWith('company') ? '#eda100' : '#2a78d6'} /><text x={points.get(n)![0]} y={points.get(n)![1] - 16} textAnchor="middle" fill="currentColor" fontSize="12">{n}</text></g>)}
    </svg> : <p>Graph disabled: direct public broadcast.</p>}
  </section>
}

export function Stage2Panel({ events }: { events: TelemetryEvent[] }) {
  const frames = useMemo(() => events.filter((e) => typeof e.payload.stage2_json === 'string').map((e) => JSON.parse(e.payload.stage2_json as string) as Frame), [events])
  const [trader, setTrader] = useState(0)
  const [company, setCompany] = useState(0)
  const [source, setSource] = useState('all')
  const [from, setFrom] = useState(1)
  const [to, setTo] = useState<number | null>(null)
  const [day, setDay] = useState<number | null>(null)
  const [playing, setPlaying] = useState(false)
  const latest = frames.at(-1)
  const history = frames.filter((f) => f.day >= from && f.day <= (to ?? latest?.day ?? 1) && f.day <= (day ?? latest?.day ?? 1))
  const frame = history.at(-1)
  useEffect(() => {
    if (!playing) return
    const timer = setInterval(() => setDay((current) => Math.min((current ?? from) + 1, to ?? latest?.day ?? 1)), 200)
    return () => clearInterval(timer)
  }, [playing, from, to, latest?.day])
  if (!latest) return <section className="chart-card"><h3>No Stage 2 telemetry in this run.</h3></section>
  const i = Math.min(trader, latest.trader_ids.length - 1), j = Math.min(company, latest.company_ids.length - 1)
  const reward = history.filter((f) => f.trader_rewards).at(-1)?.trader_rewards
  const companyReward = history.filter((f) => f.company_rewards).at(-1)?.company_rewards
  const rows = history.map((f) => {
    const q = f.q_values[f.company_groups[j]][f.company_states[j]]
    const values = [...f.wealth].sort((a, b) => a - b)
    return { day: f.day, p0: f.trader_probabilities[i]?.[0] ?? 0, p1: f.trader_probabilities[i]?.[1] ?? 0, p2: f.trader_probabilities[i]?.[2] ?? 0, p3: f.trader_probabilities[i]?.[3] ?? 0,
      q0: q[0], q1: q[1], q2: q[2], w10: values[Math.floor(values.length * .1)], w50: values[Math.floor(values.length * .5)], w90: values[Math.floor(values.length * .9)],
      a0: f.trader_actions.filter((a) => a === 0).length / values.length, a1: f.trader_actions.filter((a) => a === 1).length / values.length, a2: f.trader_actions.filter((a) => a === 2).length / values.length, a3: f.trader_actions.filter((a) => a === 3).length / values.length }
  })
  const deliveries = history.flatMap((f) => f.arrivals).filter((d) => d.target_id === latest.trader_ids[i] && (source === 'all' || d.source_id === source))
  const series = (names: string[], prefix: string) => names.map((name, k) => ({ name, field: `${prefix}${k}`, color: palette[k] }))
  return <div className="stage2-panel">
    <div className="controls"><label>Trader<select value={i} onChange={(e) => setTrader(Number(e.target.value))}>{latest.trader_ids.map((id, k) => <option key={id} value={k}>{id}</option>)}</select></label>
      <label>Company<select value={j} onChange={(e) => setCompany(Number(e.target.value))}>{latest.company_ids.map((id, k) => <option key={id} value={k}>{id}</option>)}</select></label>
      <label>Source<select value={source} onChange={(e) => setSource(e.target.value)}><option value="all">All sources</option>{latest.company_ids.map((id) => <option key={id}>{id}</option>)}</select></label>
      <label>From<input type="number" min="1" max={latest.day} value={from} onChange={(e) => setFrom(Math.max(1, Number(e.target.value)))} /></label>
      <label>To<input type="number" min={from} max={latest.day} value={to ?? latest.day} onChange={(e) => setTo(Number(e.target.value))} /></label>
      <button onClick={() => { setDay(from); setPlaying(true) }}>Play log</button><button onClick={() => setPlaying(false)}>Pause log</button><button onClick={() => { setPlaying(false); setDay((current) => Math.min((current ?? from) + 1, latest.day)) }}>Step log</button><button onClick={() => { setPlaying(false); setDay(null); setTo(null) }}>Follow latest</button>
    </div>
    <label className="replay-slider">Recorded day {frame?.day ?? '—'}<input type="range" min={from} max={to ?? latest.day} value={day ?? latest.day} onChange={(e) => { setPlaying(false); setDay(Number(e.target.value)) }} /></label>
    {!frame ? <p>No frame in this time range.</p> : <div className="chart-grid">
      <Network frame={frame} agent={frame.trader_ids[i]} company={frame.company_ids[j]} source={source} />
      <section className="chart-card"><header><div><h3>Observation, action & position</h3><p>Day {frame.day} · company private state is researcher-only</p></div></header><pre>{JSON.stringify({ trader: frame.trader_ids[i], state_at_decision: frame.trader_states[i], features_before_trade: frame.trader_features[i], arrived_news: frame.visible_news[i], subjective_value_at_close: frame.subjective_values[i], action: traderActions[frame.trader_actions[i]] ?? 'Fixed rule', submitted: frame.submitted_orders[i], executed: frame.executed_orders[i], position: frame.positions[i], wealth: frame.wealth[i], stable_preference: frame.factor_preferences[i], risk_aversion: frame.risk_aversion[i], company: frame.company_ids[j], company_action: companyActions[frame.company_actions[j]], company_cash: frame.company_cash[j], company_private_features: frame.company_features[j] }, null, 2)}</pre></section>
      <Chart title="Bandit choice probabilities" rows={rows} series={series(traderActions, 'p')} />
      <Chart title="Company Q values · decision state" rows={rows} series={series(companyActions, 'q')} />
      <Chart title="Action shares" rows={rows} series={series(traderActions, 'a')} />
      <Chart title="Wealth distribution · quantiles" rows={rows} series={series(['10th percentile', 'Median', '90th percentile'], 'w').map((s, k) => ({ ...s, field: ['w10', 'w50', 'w90'][k] }))} />
      <section className="chart-card"><h3>Last completed rewards</h3><p>Unfinished windows receive no update.</p><table><thead><tr><th>Component</th><th>Reward</th></tr></thead><tbody>{reward && (['gross_return', 'transaction_cost', 'volatility_penalty', 'drawdown_penalty', 'reward'] as const).map((key) => <tr key={key}><td>Trader {reward.start_day}–{reward.end_day} · {key}</td><td>{reward[key][i].toPrecision(6)}</td></tr>)}{companyReward?.names.map((name, k) => <tr key={name}><td>Company {companyReward.start_day}–{companyReward.end_day} · {name}</td><td>{companyReward.components[j][k].toPrecision(6)}</td></tr>)}</tbody></table></section>
      <section className="chart-card"><h3>Arrived messages · {deliveries.length}</h3><div className="table-scroll"><table><thead><tr><th>Source / path</th><th>Available</th><th>Delay</th><th>Trust</th></tr></thead><tbody>{deliveries.map((d) => <tr key={`${d.message_id}|${d.target_id}`}><td>{d.source_id}<br />{d.path.join(' → ')}</td><td>{d.available_at.slice(0, 10)}</td><td>{(Date.parse(d.available_at) - Date.parse(d.event_time)) / 86400000}d</td><td>{d.credibility.toFixed(4)}</td></tr>)}</tbody></table></div></section>
    </div>}
  </div>
}
